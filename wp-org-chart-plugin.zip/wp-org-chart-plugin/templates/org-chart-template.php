<?php
/**
 * Org Chart Template
 * 
 * This template file is currently empty and ready for future use.
 * You can use this file to create custom template overrides or
 * additional template functionality for the org chart plugin.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Add your template code here
?>
